package com.invenzo.myfirstdagger2app.manual.interfaces

fun interface Outputter {
    fun output(output: String?)
}